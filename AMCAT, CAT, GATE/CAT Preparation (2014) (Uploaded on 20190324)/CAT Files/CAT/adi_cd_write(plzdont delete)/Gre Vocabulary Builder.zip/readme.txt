GRE Vocabulary Builder:

Program Author: Chris Craft
Home Page: http://www.cjcraft.com/

World List Author: Oleg Smirnov
Home Page: http://www.uoregon.edu/~osmirnov/gre/list.html